#!/bin/bash
echo "Script executed at $(date)" >> /home/einfochips/day10/cron_test.log
