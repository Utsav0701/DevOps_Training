# Day 11 Task:

1\. Created a dev Compile build to test maven sample code.

![](.//media/image1.png)

After the successful build of dev compile it will build dev test as i
have added post build actions

![](.//media/image2.png)

![](.//media/image3.png)

2\. Create a private repo for adding credentials to access GitHub
private Repo.

![](.//media/image4.png)

![](.//media/image5.png)

For executing script.sh file fetched from GitHub private repo.

3\. Create Pipeline View to display continious build between Dev Compile
and Dev Test.

![](.//media/image6.png)

![](.//media/image7.png)